INSERT INTO tb_User
(
    Username,
    Password,
    FirstName,
    LastName,
    Email,
    IsActive
)
select
    'Marty'              AS  Username,
    'Ab123456'     AS   Password,
    'martin'                               AS   FirstName,
    'Benda'                               AS   LastName,
    'martin.benda@gmail.com'                          AS   Email,
    1                               AS   IsActive
;



INSERT INTO tb_User
(
    Username,
    Password,
    FirstName,
    LastName,
    Email,
    IsActive
)
select
    'panak'              AS  Username,
    'Ab123456'     AS   Password,
    'Daniel'                               AS   FirstName,
    'Panacek'                               AS   LastName,
    'panacek.daniel@gmail.com'                          AS   Email,
    1                               AS   IsActive
;


INSERT INTO tb_User
(
    Username,
    Password,
    FirstName,
    LastName,
    Email,
    IsActive
)
select
    'Macek'              AS  Username,
    'Ab123456'     AS   Password,
    'Vojta'                               AS   FirstName,
    'Macík'                               AS   LastName,
    'vojta.macík@gmail.com'                          AS   Email,
    1                               AS   IsActive
;


INSERT INTO tb_User
(
    Username,
    Password,
    FirstName,
    LastName,
    Email,
    IsActive
)
select
    'User123'              AS  Username,
    'Ab123456'     AS   Password,
    'Noname'                               AS   FirstName,
    'Noname'                               AS   LastName,
    'Noname@gmail.com'                          AS   Email,
    1                               AS   IsActive
;