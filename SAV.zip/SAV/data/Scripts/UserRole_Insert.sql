INSERT INTO tb_UserRole
(
    User_ID,
    Role_ID
)
select
    1        AS  User_ID,
    1     AS   Role_ID
;

INSERT INTO tb_UserRole
(
    User_ID,
    Role_ID
)
select
    2       AS  User_ID,
    1     AS   Role_ID
;


INSERT INTO tb_UserRole
(
    User_ID,
    Role_ID
)
select
    3       AS  User_ID,
    3     AS   Role_ID
;

INSERT INTO tb_UserRole
(
    User_ID,
    Role_ID
)
select
    4       AS  User_ID,
    2     AS   Role_ID
;